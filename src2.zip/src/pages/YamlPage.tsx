/* src/pages/YamlPage.tsx - VERSÃO CORRIGIDA */
import React, { useState, useEffect } from 'react';
import { Plus, Download, Upload, RefreshCw, CheckCircle, AlertCircle, FileText } from 'lucide-react';
import { YamlFile, YamlFileType, YamlGenerationRequest } from '../types';
import YamlFileCard from '../components/yaml/YamlFileCard';
import YamlGenerationModal from '../components/yaml/YamlGenerationModal';
import YamlEditorModal from '../components/yaml/YamlEditorModal';
import './YamlPage.css';

// Mock data for demonstration
const mockYamlFiles: YamlFile[] = [
  {
    id: '1',
    name: 'agents.yaml',
    type: 'agent',
    content: `customer_service_agent:
  role: >
    You are a customer service specialist responsible for handling customer queries
  goal: >
    Understand customer needs and provide appropriate solutions or routing
  backstory: >
    You have 5 years of experience in customer service and deep knowledge of
    company products and policies
  tools:
    - knowledge_base_tool
    - ticket_creation_tool
    - customer_history_tool
  verbose: true
  allow_delegation: false`,
    lastModified: '2024-03-15T10:30:00',
    size: 1024,
    validationIssues: [
      { 
        type: 'success', 
        message: 'All agents have required fields',
        severity: 'info',
        line: 0
      }
    ]
  },
  {
    id: '2',
    name: 'tasks.yaml',
    type: 'task',
    content: `process_customer_query:
  description: >
    Analyze incoming customer query and determine appropriate response path
  expected_output: >
    Structured classification with priority level and routing information
  agent: customer_service_agent
  tools:
    - text_analysis_tool
    - classification_model
    - priority_assessment_tool`,
    lastModified: '2024-03-15T11:00:00',
    size: 768,
    validationIssues: [
      { 
        type: 'warning', 
        message: 'Consider adding context field for better task chaining',
        severity: 'warning',
        line: 5
      }
    ]
  },
  {
    id: '3',
    name: 'tools.yaml',
    type: 'tool',
    content: `knowledge_base_tool:
  type: "RAG"
  description: "Search company knowledge base for relevant information"
  
ticket_creation_tool:
  type: "API"
  description: "Create support tickets in the ticketing system"
  
customer_history_tool:
  type: "Database"
  description: "Access customer interaction history"`,
    lastModified: '2024-03-15T09:45:00',
    size: 512,
    validationIssues: [
      { 
        type: 'error', 
        message: 'Missing required field "parameters" in knowledge_base_tool',
        severity: 'error',
        line: 2
      },
      { 
        type: 'info', 
        message: 'Consider adding authentication configuration',
        severity: 'info',
        line: 8
      }
    ]
  }
];

const YamlPage: React.FC = () => {
  const [yamlFiles, setYamlFiles] = useState<YamlFile[]>(mockYamlFiles);
  const [selectedType, setSelectedType] = useState<YamlFileType | 'all'>('all');
  const [selectedFile, setSelectedFile] = useState<YamlFile | null>(null);
  const [showGenerationModal, setShowGenerationModal] = useState(false);
  const [showEditorModal, setShowEditorModal] = useState(false);
  const [additionalInstructions, setAdditionalInstructions] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Helper function to check if file is valid
  const isFileValid = (file: YamlFile): boolean => {
    return !file.validationIssues.some(issue => issue.severity === 'error');
  };

  // Filter files based on type and search
  const filteredFiles = yamlFiles.filter(file => {
    const matchesType = selectedType === 'all' || file.type === selectedType;
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         file.content.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  // Count files by type
  const fileCounts = {
    all: yamlFiles.length,
    agent: yamlFiles.filter(f => f.type === 'agent').length,
    task: yamlFiles.filter(f => f.type === 'task').length,
    tool: yamlFiles.filter(f => f.type === 'tool').length,
    crew: yamlFiles.filter(f => f.type === 'crew').length
  };

  // Count validation status
  const validationCounts = {
    valid: yamlFiles.filter(f => isFileValid(f)).length,
    invalid: yamlFiles.filter(f => !isFileValid(f)).length,
    warnings: yamlFiles.filter(f => 
      f.validationIssues.some(m => m.severity === 'warning')
    ).length
  };

  const handleGenerateYaml = () => {
    setShowGenerationModal(true);
  };

  const handleGenerationComplete = (request: YamlGenerationRequest) => {
    // Simulate generating YAML files based on the request
    const newFiles: YamlFile[] = [];
    
    if (request.generateAgents) {
      newFiles.push({
        id: Date.now().toString(),
        name: 'generated_agents.yaml',
        type: 'agent',
        content: '# Generated agents YAML\n',
        lastModified: new Date().toISOString(),
        size: 256,
        validationIssues: []
      });
    }
    
    if (request.generateTasks) {
      newFiles.push({
        id: (Date.now() + 1).toString(),
        name: 'generated_tasks.yaml',
        type: 'task',
        content: '# Generated tasks YAML\n',
        lastModified: new Date().toISOString(),
        size: 256,
        validationIssues: []
      });
    }
    
    setYamlFiles([...yamlFiles, ...newFiles]);
    setShowGenerationModal(false);
  };

  const handleEditFile = (fileId: string) => {
    const file = yamlFiles.find(f => f.id === fileId);
    if (file) {
      setSelectedFile(file);
      setShowEditorModal(true);
    }
  };

  const handleSaveFile = (fileId: string, content: string) => {
    setYamlFiles(yamlFiles.map(f => 
      f.id === fileId 
        ? { ...f, content, lastModified: new Date().toISOString() }
        : f
    ));
    setShowEditorModal(false);
  };

  const handleDeleteFile = (fileId: string) => {
    if (window.confirm('Are you sure you want to delete this file?')) {
      setYamlFiles(yamlFiles.filter(f => f.id !== fileId));
    }
  };

  const handleValidateAll = async () => {
    // Simulate validation
    const updatedFiles = yamlFiles.map(file => {
      // Mock validation logic
      const newValidation: YamlFile['validationIssues'] = [];
      
      if (file.type === 'agent' && !file.content.includes('role:')) {
        newValidation.push({ 
          type: 'error', 
          message: 'Missing required field "role"',
          severity: 'error',
          line: 1
        });
      }
      
      if (file.type === 'task' && !file.content.includes('context:')) {
        newValidation.push({ 
          type: 'warning', 
          message: 'Consider adding context field',
          severity: 'warning',
          line: 5
        });
      }
      
      if (newValidation.length === 0) {
        newValidation.push({ 
          type: 'success', 
          message: 'Validation passed',
          severity: 'info',
          line: 0
        });
      }
      
      return {
        ...file,
        validationIssues: newValidation
      };
    });
    
    setYamlFiles(updatedFiles);
  };

  const handleExportAll = async () => {
    // Create a simple implementation without JSZip
    const combinedContent = yamlFiles.map(file => 
      `# ${file.name}\n${file.content}\n\n`
    ).join('---\n');
    
    const blob = new Blob([combinedContent], { type: 'text/yaml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'yaml_config_all.yaml';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportFiles = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;
    
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        let type: YamlFileType = 'agent';
        
        // Determine type from filename
        if (file.name.includes('task')) type = 'task';
        else if (file.name.includes('tool')) type = 'tool';
        else if (file.name.includes('crew')) type = 'crew';
        
        const newFile: YamlFile = {
          id: Date.now().toString(),
          name: file.name,
          type: type,
          content: content,
          lastModified: new Date().toISOString(),
          size: file.size,
          validationIssues: []
        };
        
        setYamlFiles(prev => [...prev, newFile]);
      };
      reader.readAsText(file);
    });
  };

  return (
    <div className="yaml-page">
      <div className="yaml-header">
        <div className="yaml-header-left">
          <h1>YAML Configuration</h1>
          <p>Manage and validate your agent system configuration files</p>
        </div>
        <div className="yaml-header-actions">
          <button className="yaml-action-button secondary" onClick={handleValidateAll}>
            <CheckCircle size={18} />
            Validate All
          </button>
          <button className="yaml-action-button secondary" onClick={handleExportAll}>
            <Download size={18} />
            Export All
          </button>
          <label className="yaml-action-button secondary">
            <Upload size={18} />
            Import
            <input
              type="file"
              multiple
              accept=".yaml,.yml"
              onChange={handleImportFiles}
              style={{ display: 'none' }}
            />
          </label>
          <button className="yaml-action-button primary" onClick={handleGenerateYaml}>
            <Plus size={18} />
            Generate YAML
          </button>
        </div>
      </div>

      <div className="yaml-instructions">
        <h3>Additional Instructions for YAML Generation</h3>
        <p>Provide any specific instructions or requirements for the AI agent to consider when generating YAML files:</p>
        <textarea
          value={additionalInstructions}
          onChange={(e) => setAdditionalInstructions(e.target.value)}
          placeholder="Example: Use GPT-4 for all agents, include error handling tasks, add monitoring tools..."
          rows={3}
        />
      </div>

      <div className="yaml-content">
        <div className="yaml-sidebar">
          <div className="yaml-search">
            <input
              type="text"
              placeholder="Search files..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="yaml-filters">
            <h3>File Types</h3>
            <div className="yaml-filter-list">
              {(['all', 'agent', 'task', 'tool', 'crew'] as const).map(type => (
                <button
                  key={type}
                  className={`yaml-filter-item ${selectedType === type ? 'active' : ''}`}
                  onClick={() => setSelectedType(type)}
                >
                  <FileText size={16} />
                  <span>{type.charAt(0).toUpperCase() + type.slice(1)}s</span>
                  <span className="yaml-filter-count">{fileCounts[type]}</span>
                </button>
              ))}
            </div>
          </div>
          
          <div className="yaml-validation-summary">
            <h3>Validation Status</h3>
            <div className="yaml-validation-stats">
              <div className="yaml-stat valid">
                <CheckCircle size={16} />
                <span>Valid: {validationCounts.valid}</span>
              </div>
              <div className="yaml-stat invalid">
                <AlertCircle size={16} />
                <span>Invalid: {validationCounts.invalid}</span>
              </div>
              <div className="yaml-stat warnings">
                <AlertCircle size={16} />
                <span>Warnings: {validationCounts.warnings}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="yaml-main">
          {filteredFiles.length === 0 ? (
            <div className="yaml-empty-state">
              <FileText size={48} />
              <h3>No YAML files found</h3>
              <p>Generate new YAML files from your specifications or import existing ones.</p>
              <button className="yaml-action-button primary" onClick={handleGenerateYaml}>
                <Plus size={18} />
                Generate YAML
              </button>
            </div>
          ) : (
            <div className="yaml-files-grid">
              {filteredFiles.map(file => (
                <YamlFileCard
                  key={file.id}
                  yamlFile={file}
                  onEdit={handleEditFile}
                  onDelete={handleDeleteFile}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {showGenerationModal && (
        <YamlGenerationModal
          onClose={() => setShowGenerationModal(false)}
          onGenerate={handleGenerationComplete}
          additionalInstructions={additionalInstructions}
        />
      )}

      {showEditorModal && selectedFile && (
        <YamlEditorModal
          file={selectedFile}
          onClose={() => setShowEditorModal(false)}
          onSave={handleSaveFile}
        />
      )}
    </div>
  );
};

export default YamlPage;