// src/types/navigation.ts (NOVO ARQUIVO)
export interface ProjectContext {
    projectId: string;
    projectName: string;
    isInProject: boolean;
  }
  