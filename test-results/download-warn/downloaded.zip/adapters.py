"""
Adapters for task input/output mapping.

Each task has two functions:
- TASK_input_func(state: dict) -> dict: extracts parameters for the task from the state.
- TASK_output_func(state: dict, result: Any) -> dict: updates state with the task result.
"""

from typing import Any, Dict
import json

def upload_extract_edital_input_func(state: dict) -> dict:
    """Extract input for upload_extract_edital task."""
    return {
        'edital_file': state['initial_inputs'].get('edital_file'),
        'processo_numero': state['initial_inputs'].get('processo_numero', ''),
        'orgao': state['initial_inputs'].get('orgao', '')
    }

def upload_extract_edital_output_func(state: dict, result: Any) -> dict:
    """Store the result of upload_extract_edital."""
    state['outputs']['upload_extract_edital'] = result
    state['extracted_text'] = result.get('extracted_text', '')
    state['metadata'] = result.get('metadata', {})
    return state

def identify_applicable_laws_input_func(state: dict) -> dict:
    """Extract input for identify_applicable_laws task."""
    output = state['outputs'].get('upload_extract_edital', {})
    return {
        'extracted_text': output.get('extracted_text', ''),
        'metadata': output.get('metadata', {}),
        'document_id': output.get('document_id', '')
    }

def identify_applicable_laws_output_func(state: dict, result: Any) -> dict:
    state['outputs']['identify_applicable_laws'] = result
    state['laws_list'] = result.get('laws_list', [])
    state['mapping'] = result.get('mapping', {})
    return state

def compare_edital_laws_input_func(state: dict) -> dict:
    output = state['outputs'].get('identify_applicable_laws', {})
    return {
        'extracted_text': output.get('extracted_text', state.get('extracted_text', '')),
        'laws_list': output.get('laws_list', state.get('laws_list', [])),
        'mapping': output.get('mapping', state.get('mapping', {}))
    }

def compare_edital_laws_output_func(state: dict, result: Any) -> dict:
    state['outputs']['compare_edital_laws'] = result
    state['comparison_report'] = result.get('comparison_report', {})
    state['potential_issues'] = result.get('potential_issues', [])
    state['similarity_scores'] = result.get('similarity_scores', {})
    return state

def detect_legal_inconsistencies_input_func(state: dict) -> dict:
    output = state['outputs'].get('compare_edital_laws', {})
    return {
        'comparison_report': output.get('comparison_report', state.get('comparison_report', {})),
        'potential_issues': output.get('potential_issues', state.get('potential_issues', [])),
        'similarity_scores': output.get('similarity_scores', state.get('similarity_scores', {})),
        'extracted_text': output.get('extracted_text', state.get('extracted_text', '')),
        'laws_list': output.get('laws_list', state.get('laws_list', []))
    }

def detect_legal_inconsistencies_output_func(state: dict, result: Any) -> dict:
    state['outputs']['detect_legal_inconsistencies'] = result
    state['inconsistencies'] = result.get('inconsistencies', [])
    state['detection_summary'] = result.get('detection_summary', {})
    return state

def classify_inconsistency_severity_input_func(state: dict) -> dict:
    output = state['outputs'].get('detect_legal_inconsistencies', {})
    classification_rules = state['configuration'].get('classification_rules', {})
    return {
        'inconsistencies': output.get('inconsistencies', state.get('inconsistencies', [])),
        'detection_summary': output.get('detection_summary', state.get('detection_summary', {})),
        'classification_rules': classification_rules
    }

def classify_inconsistency_severity_output_func(state: dict, result: Any) -> dict:
    state['outputs']['classify_inconsistency_severity'] = result
    state['classified_inconsistencies'] = result.get('classified_inconsistencies', [])
    state['severity_summary'] = result.get('severity_summary', {})
    return state

def suggest_petition_type_input_func(state: dict) -> dict:
    output = state['outputs'].get('classify_inconsistency_severity', {})
    return {
        'classified_inconsistencies': output.get('classified_inconsistencies', state.get('classified_inconsistencies', [])),
        'severity_summary': output.get('severity_summary', state.get('severity_summary', {})),
        'process_metadata': state.get('metadata', {})
    }

def suggest_petition_type_output_func(state: dict, result: Any) -> dict:
    state['outputs']['suggest_petition_type'] = result
    state['suggestions'] = result.get('suggestions', [])
    state['overall_recommendation'] = result.get('overall_recommendation', '')
    return state

def generate_petition_auto_input_func(state: dict) -> dict:
    output = state['outputs'].get('suggest_petition_type', {})
    return {
        'suggestions': output.get('suggestions', state.get('suggestions', [])),
        'overall_recommendation': output.get('overall_recommendation', state.get('overall_recommendation', '')),
        'classified_inconsistencies': state.get('classified_inconsistencies', []),
        'template_type': state['initial_inputs'].get('template_type', 'impugnacao'),
        'process_metadata': state.get('metadata', {})
    }

def generate_petition_auto_output_func(state: dict, result: Any) -> dict:
    state['outputs']['generate_petition_auto'] = result
    state['petition_draft'] = result.get('petition_draft', '')
    state['sections_generated'] = result.get('sections_generated', {})
    state['generation_metadata'] = result.get('generation_metadata', {})
    return state

def apply_specific_template_input_func(state: dict) -> dict:
    output = state['outputs'].get('generate_petition_auto', {})
    return {
        'petition_draft': output.get('petition_draft', state.get('petition_draft', '')),
        'sections_generated': output.get('sections_generated', state.get('sections_generated', {})),
        'generation_metadata': output.get('generation_metadata', state.get('generation_metadata', {})),
        'template_type': state['initial_inputs'].get('template_type', 'impugnacao'),
        'mandatory_sections': state['configuration'].get('mandatory_sections', [])
    }

def apply_specific_template_output_func(state: dict, result: Any) -> dict:
    state['outputs']['apply_specific_template'] = result
    state['templated_draft'] = result.get('templated_draft', '')
    state['missing_sections'] = result.get('missing_sections', [])
    state['template_compliance'] = result.get('template_compliance', False)
    return state

def manage_document_editing_input_func(state: dict) -> dict:
    output = state['outputs'].get('apply_specific_template', {})
    return {
        'templated_draft': output.get('templated_draft', state.get('templated_draft', '')),
        'missing_sections': output.get('missing_sections', state.get('missing_sections', [])),
        'template_compliance': output.get('template_compliance', state.get('template_compliance', False)),
        'edit_requests': state['initial_inputs'].get('edit_requests', []),
        'user_context': state['initial_inputs'].get('user_context', {})
    }

def manage_document_editing_output_func(state: dict, result: Any) -> dict:
    state['outputs']['manage_document_editing'] = result
    state['edited_document'] = result.get('edited_document', '')
    state['edit_metadata'] = result.get('edit_metadata', {})
    state['variables_replaced'] = result.get('variables_replaced', [])
    return state

def register_change_log_input_func(state: dict) -> dict:
    return {
        'previous_version': state.get('templated_draft', ''),
        'new_version': state.get('edited_document', ''),
        'user_info': state['initial_inputs'].get('user_context', {}),
        'change_description': state['initial_inputs'].get('change_description', '')
    }

def register_change_log_output_func(state: dict, result: Any) -> dict:
    state['outputs']['register_change_log'] = result
    state['change_log_entry'] = result.get('change_log_entry', {})
    state['version_id'] = result.get('version_id', '')
    state['audit_trail'] = result.get('audit_trail', [])
    return state

def monitor_portal_status_input_func(state: dict) -> dict:
    return {
        'processo_numero': state['initial_inputs'].get('processo_numero', ''),
        'portal_config': state['initial_inputs'].get('portal_config', {}),
        'last_check': state.get('last_check')
    }

def monitor_portal_status_output_func(state: dict, result: Any) -> dict:
    state['outputs']['monitor_portal_status'] = result
    state['current_status'] = result.get('current_status', '')
    state['status_changed'] = result.get('status_changed', False)
    state['check_timestamp'] = result.get('check_timestamp', None)
    state['raw_response'] = result.get('raw_response', {})
    return state

def detect_status_change_input_func(state: dict) -> dict:
    output = state['outputs'].get('monitor_portal_status', {})
    return {
        'previous_status': state.get('previous_status', ''),
        'current_status': output.get('current_status', state.get('current_status', '')),
        'status_history': state.get('status_history', [])
    }

def detect_status_change_output_func(state: dict, result: Any) -> dict:
    state['outputs']['detect_status_change'] = result
    state['change_detected'] = result.get('change_detected', False)
    state['change_type'] = result.get('change_type', '')
    state['detection_timestamp'] = result.get('detection_timestamp', None)
    state['confidence_score'] = result.get('confidence_score', 0.0)
    return state

def trigger_multi_channel_notification_input_func(state: dict) -> dict:
    output = state['outputs'].get('detect_status_change', {})
    return {
        'change_event': {
            'processo': state['initial_inputs'].get('processo_numero', ''),
            'timestamp': output.get('detection_timestamp'),
            'portal': state['initial_inputs'].get('portal_config', {}).get('name', '')
        },
        'user_preferences': state['initial_inputs'].get('user_preferences', {}),
        'message_template': state['initial_inputs'].get('message_template', '')
    }

def trigger_multi_channel_notification_output_func(state: dict, result: Any) -> dict:
    state['outputs']['trigger_multi_channel_notification'] = result
    state['notifications_sent'] = result.get('notifications_sent', [])
    state['delivery_summary'] = result.get('delivery_summary', {})
    state['urgency_level'] = result.get('urgency_level', '')
    return state

def analyze_winning_proposal_input_func(state: dict) -> dict:
    return {
        'proposal_file': state['initial_inputs'].get('proposal_file'),
        'edital_data': state.get('outputs', {}).get('detect_legal_inconsistencies', {}),
        'applicable_laws': state.get('laws_list', [])
    }

def analyze_winning_proposal_output_func(state: dict, result: Any) -> dict:
    state['outputs']['analyze_winning_proposal'] = result
    state['proposal_inconsistencies'] = result.get('proposal_inconsistencies', [])
    state['comparison_report'] = result.get('comparison_report', {})
    state['severity_classification'] = result.get('severity_classification', {})
    return state

def manage_analysis_checklist_input_func(state: dict) -> dict:
    return {
        'checklist_template': state['configuration'].get('checklist_template', {}),
        'proposal_context': state.get('proposal_inconsistencies', []),
        'user_customizations': state['initial_inputs'].get('checklist_customizations', [])
    }

def manage_analysis_checklist_output_func(state: dict, result: Any) -> dict:
    state['outputs']['manage_analysis_checklist'] = result
    state['active_checklist'] = result.get('active_checklist', {})
    state['completion_percentage'] = result.get('completion_percentage', 0.0)
    state['flagged_items'] = result.get('flagged_items', [])
    return state

def suggest_recurso_motivations_input_func(state: dict) -> dict:
    output = state['outputs'].get('analyze_winning_proposal', {})
    return {
        'proposal_inconsistencies': output.get('proposal_inconsistencies', state.get('proposal_inconsistencies', [])),
        'severity_classification': output.get('severity_classification', state.get('severity_classification', {})),
        'legal_context': state['configuration'].get('legal_context', {})
    }

def suggest_recurso_motivations_output_func(state: dict, result: Any) -> dict:
    state['outputs']['suggest_recurso_motivations'] = result
    state['suggested_motivations'] = result.get('suggested_motivations', [])
    state['selection_interface'] = result.get('selection_interface', {})
    return state

def legal_assistance_chat_input_func(state: dict) -> dict:
    return {
        'user_question': state['initial_inputs'].get('user_question', ''),
        'chat_context': {
            'processo': state.get('metadata', {}).get('numero_processo', ''),
            'inconsistencies': state.get('proposal_inconsistencies', []),
            'history': state.get('chat_history', [])
        },
        'legal_database': state['configuration'].get('legal_database', {})
    }

def legal_assistance_chat_output_func(state: dict, result: Any) -> dict:
    state['outputs']['legal_assistance_chat'] = result
    state['ai_response'] = result.get('ai_response', '')
    state['sources_cited'] = result.get('sources_cited', [])
    state['suggested_actions'] = result.get('suggested_actions', [])
    state.setdefault('chat_history', []).append({
        'user': state['initial_inputs'].get('user_question', ''),
        'ai': state['ai_response']
    })
    return state

def prepare_portal_submission_input_func(state: dict) -> dict:
    return {
        'final_document': state.get('edited_document', state.get('petition_draft', '')),
        'portal_requirements': state['initial_inputs'].get('portal_requirements', {}),
        'process_metadata': state.get('metadata', {})
    }

def prepare_portal_submission_output_func(state: dict, result: Any) -> dict:
    state['outputs']['prepare_portal_submission'] = result
    state['submission_ready_files'] = result.get('submission_ready_files', [])
    state['validation_report'] = result.get('validation_report', {})
    state['pre_submission_check'] = result.get('pre_submission_check', False)
    return state

def execute_automatic_submission_input_func(state: dict) -> dict:
    output = state['outputs'].get('prepare_portal_submission', {})
    return {
        'submission_ready_files': output.get('submission_ready_files', state.get('submission_ready_files', [])),
        'portal_config': state['initial_inputs'].get('portal_config', {}),
        'submission_data': state['initial_inputs'].get('submission_data', {})
    }

def execute_automatic_submission_output_func(state: dict, result: Any) -> dict:
    state['outputs']['execute_automatic_submission'] = result
    state['submission_result'] = result.get('submission_result', {})
    state['portal_response'] = result.get('portal_response', {})
    state['error_details'] = result.get('error_details', {})
    return state

def manage_open_bid_dispute_input_func(state: dict) -> dict:
    return {
        'dispute_config': state['initial_inputs'].get('dispute_config', {}),
        'bid_events': state['initial_inputs'].get('bid_events', []),
        'dispute_rules': state['configuration'].get('dispute_rules', {})
    }

def manage_open_bid_dispute_output_func(state: dict, result: Any) -> dict:
    state['outputs']['manage_open_bid_dispute'] = result
    state['dispute_state'] = result.get('dispute_state', {})
    state['winner_declaration'] = result.get('winner_declaration', {})
    state['audit_log'] = result.get('audit_log', [])
    return state

def manage_open_closed_bid_dispute_input_func(state: dict) -> dict:
    return {
        'dispute_config': state['initial_inputs'].get('dispute_config', {}),
        'open_phase_results': state.get('dispute_state', {}),
        'closed_bids': state['initial_inputs'].get('closed_bids', [])
    }

def manage_open_closed_bid_dispute_output_func(state: dict, result: Any) -> dict:
    state['outputs']['manage_open_closed_bid_dispute'] = result
    state['phase_status'] = result.get('phase_status', '')
    state['final_ranking'] = result.get('final_ranking', [])
    state['winner'] = result.get('winner', {})
    return state

def manage_users_and_profiles_input_func(state: dict) -> dict:
    return {
        'user_data': state['initial_inputs'].get('user_data', {}),
        'action': state['initial_inputs'].get('action', 'create'),
        'admin_context': state['initial_inputs'].get('admin_context', {})
    }

def manage_users_and_profiles_output_func(state: dict, result: Any) -> dict:
    state['outputs']['manage_users_and_profiles'] = result
    state['user_record'] = result.get('user_record', {})
    state['permission_summary'] = result.get('permission_summary', {})
    state['audit_entry'] = result.get('audit_entry', {})
    return state

def configure_mfa_input_func(state: dict) -> dict:
    return {
        'user_id': state['user_record'].get('id', '') if 'user_record' in state else state['initial_inputs'].get('user_id', ''),
        'mfa_action': state['initial_inputs'].get('mfa_action', 'enable'),
        'user_profile': state['user_record'].get('perfil', '') if 'user_record' in state else state['initial_inputs'].get('user_profile', '')
    }

def configure_mfa_output_func(state: dict, result: Any) -> dict:
    state['outputs']['configure_mfa'] = result
    state['mfa_status'] = result.get('mfa_status', {})
    state['security_level'] = result.get('security_level', '')
    state['compliance_check'] = result.get('compliance_check', False)
    return state

def manage_petition_templates_input_func(state: dict) -> dict:
    return {
        'template_data': state['initial_inputs'].get('template_data', {}),
        'action': state['initial_inputs'].get('action', 'create'),
        'admin_context': state['initial_inputs'].get('admin_context', {})
    }

def manage_petition_templates_output_func(state: dict, result: Any) -> dict:
    state['outputs']['manage_petition_templates'] = result
    state['template_record'] = result.get('template_record', {})
    state['validation_errors'] = result.get('validation_errors', [])
    state['impact_analysis'] = result.get('impact_analysis', {})
    return state

def configure_analysis_rules_input_func(state: dict) -> dict:
    return {
        'rule_set': state['initial_inputs'].get('rule_set', {}),
        'analysis_parameters': state['initial_inputs'].get('analysis_parameters', {}),
        'admin_context': state['initial_inputs'].get('admin_context', {})
    }

def configure_analysis_rules_output_func(state: dict, result: Any) -> dict:
    state['outputs']['configure_analysis_rules'] = result
    state['active_rules'] = result.get('active_rules', {})
    state['validation_report'] = result.get('validation_report', {})
    state['performance_impact'] = result.get('performance_impact', {})
    return state

def audit_system_actions_input_func(state: dict) -> dict:
    return {
        'audit_period': state['initial_inputs'].get('audit_period', {}),
        'action_types': state['initial_inputs'].get('action_types', None),
        'user_filter': state['initial_inputs'].get('user_filter', None)
    }

def audit_system_actions_output_func(state: dict, result: Any) -> dict:
    state['outputs']['audit_system_actions'] = result
    state['audit_report'] = result.get('audit_report', {})
    state['anomalies'] = result.get('anomalies', [])
    state['compliance_score'] = result.get('compliance_score', 0.0)
    return state

def verify_gdpr_compliance_input_func(state: dict) -> dict:
    return {
        'compliance_checklist': state['initial_inputs'].get('compliance_checklist', {}),
        'data_inventory': state['initial_inputs'].get('data_inventory', {}),
        'privacy_settings': state['initial_inputs'].get('privacy_settings', {})
    }

def verify_gdpr_compliance_output_func(state: dict, result: Any) -> dict:
    state['outputs']['verify_gdpr_compliance'] = result
    state['compliance_report'] = result.get('compliance_report', {})
    state['risk_assessment'] = result.get('risk_assessment', {})
    state['action_items'] = result.get('action_items', [])
    return state


# ─── Bindings de tools (deterministic, extraído do agent_task_spec) ───
AGENT_TOOLS = {
    'configuration_agent': ['template_manager_tool', 'checklist_editor_tool', 'config_database_tool'],
    'dispute_manager_agent': ['timer_tool', 'bid_tracker_tool', 'winner_detector_tool'],
    'document_editor_agent': ['document_versioning_tool', 'diff_tool', 'format_validator_tool'],
    'edital_processor_agent': ['pdf_reader', 'docx_reader', 'txt_reader', 'text_extraction_tool'],
    'inconsistency_detector_agent': ['semantic_comparison_tool', 'legal_database_tool', 'classification_tool'],
    'legal_analyzer_agent': ['vector_search_tool', 'legal_database_tool', 'api_call_tool'],
    'legal_assistant_agent': ['legal_database_tool', 'jurisprudence_search_tool', 'chat_interface_tool'],
    'monitoring_agent': ['api_call_tool', 'web_scraper_tool', 'status_checker_tool'],
    'notification_agent': ['whatsapp_api_tool', 'email_api_tool', 'push_notification_tool'],
    'petition_generator_agent': ['template_engine_tool', 'legal_database_tool', 'document_structure_tool'],
    'proposal_analyzer_agent': ['comparison_tool', 'checklist_tool', 'technical_validator_tool'],
    'security_auditor_agent': ['log_analyzer_tool', 'compliance_checker_tool', 'gdpr_validator_tool'],
    'submission_agent': ['api_call_tool', 'file_converter_tool', 'portal_adapter_tool'],
    'user_management_agent': ['user_database_tool', 'auth_validator_tool', 'role_manager_tool'],
}

TASK_TOOLS = {
    'analyze_winning_proposal': ['document_comparison_tool', 'technical_validator_tool', 'compliance_checker_tool'],
    'apply_specific_template': ['template_selector_tool', 'section_enforcer_tool', 'legal_structure_tool'],
    'audit_system_actions': ['log_analyzer_tool', 'integrity_checker_tool', 'pattern_detector_tool'],
    'classify_inconsistency_severity': ['classification_tool', 'severity_rules_tool', 'pattern_analyzer_tool'],
    'compare_edital_laws': ['semantic_comparison_tool', 'embedding_tool', 'similarity_calculator_tool'],
    'configure_analysis_rules': ['rule_editor_tool', 'parameter_manager_tool', 'validation_tool'],
    'configure_mfa': ['mfa_manager_tool', 'totp_generator_tool', 'security_policy_tool'],
    'detect_legal_inconsistencies': ['inconsistency_detector_tool', 'legal_validator_tool', 'rule_engine_tool'],
    'detect_status_change': ['change_detector_tool', 'pattern_matcher_tool', 'state_machine_tool'],
    'execute_automatic_submission': ['api_call_tool', 'portal_adapter_tool', 'response_handler_tool'],
    'generate_petition_auto': ['template_engine_tool', 'content_generator_tool', 'structure_validator_tool'],
    'identify_applicable_laws': ['vector_search_tool', 'legal_database_tool', 'pattern_matcher_tool'],
    'legal_assistance_chat': ['chat_interface_tool', 'context_retriever_tool', 'legal_research_tool'],
    'manage_analysis_checklist': ['checklist_manager_tool', 'template_editor_tool', 'completion_tracker_tool'],
    'manage_document_editing': ['wysiwyg_editor_tool', 'variable_injector_tool', 'format_manager_tool'],
    'manage_open_bid_dispute': ['timer_tool', 'bid_tracker_tool', 'winner_detector_tool'],
    'manage_open_closed_bid_dispute': ['phase_manager_tool', 'secret_bid_tool', 'ranking_calculator_tool'],
    'manage_petition_templates': ['template_manager_tool', 'structure_validator_tool', 'version_control_tool'],
    'manage_users_and_profiles': ['user_database_tool', 'role_manager_tool', 'auth_validator_tool'],
    'monitor_portal_status': ['api_call_tool', 'status_checker_tool', 'interval_scheduler_tool'],
    'prepare_portal_submission': ['file_converter_tool', 'size_validator_tool', 'splitter_tool'],
    'register_change_log': ['change_tracker_tool', 'diff_analyzer_tool', 'log_storage_tool'],
    'suggest_petition_type': ['suggestion_engine_tool', 'business_rules_tool', 'decision_tree_tool'],
    'suggest_recurso_motivations': ['motivation_generator_tool', 'categorization_tool', 'argument_strength_calculator_tool'],
    'trigger_multi_channel_notification': ['whatsapp_api_tool', 'email_api_tool', 'push_notification_tool'],
    'upload_extract_edital': ['pdf_reader', 'docx_reader', 'text_extraction_tool'],
    'verify_gdpr_compliance': ['gdpr_validator_tool', 'consent_manager_tool', 'breach_notifier_tool'],
}

