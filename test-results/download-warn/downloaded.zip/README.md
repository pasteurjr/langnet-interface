# Sistema Agêntico

Sistema multi-agente CrewAI orquestrado por Rede de Petri, gerado pelo LangNet Interface.

## Arquitetura

- `main.py` sobe o servidor WebSocket na porta `5002`.
- `websocket_server.py` recebe `execute_task` e dispara CrewAI com `Agent`/`Task` de `agents.yaml`/`tasks.yaml`.
- `adapters.py` contém `input_func`/`output_func` por task.
- `tools.py` contém tools customizadas.
- `petri_net.json` é a Rede de Petri, com `place.logica` JavaScript que abre WebSocket para esse servidor.

A Rede de Petri é executada pelo `petri-net-editor` (frontend) ou pelo runner Node.js do `experimental_petri`.

## Como rodar

```bash
cp .env.example .env
# preencha as variáveis em .env

pip install -r requirements.txt
python main.py
```

Ou com Docker:

```bash
docker-compose up --build
```

## Estrutura

- `main.py`
- `websocket_server.py`
- `tools.py`
- `adapters.py`
- `agents.yaml`
- `tasks.yaml`
- `petri_net.json`
- `requirements.txt`
- `.env.example`
- `docker-compose.yml`
- `Dockerfile`
