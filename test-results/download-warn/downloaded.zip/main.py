"""
Sistema Agêntico — entrypoint
Sobe o servidor WebSocket na porta 5002 que recebe execute_task
e dispara a task CrewAI correspondente.
"""
import asyncio
import os
from dotenv import load_dotenv

from websocket_server import run_websocket_server

load_dotenv()

PROJECT_NAME = "Sistema Agêntico"


def main():
    port = int(os.getenv("WEBSOCKET_PORT", "5002"))
    host = os.getenv("WEBSOCKET_HOST", "localhost")
    print(f"🚀 {PROJECT_NAME} — WebSocket server em ws://{host}:{port}")
    asyncio.run(run_websocket_server(host=host, port=port))


if __name__ == "__main__":
    main()
