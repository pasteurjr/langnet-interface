"""
WebSocket server compatível com o padrão visualtasksexec.
Recebe {"type":"execute_task", "data":{"task_name", "input_data"}}
e emite task_start / verbose / task_completed / error.
"""
import asyncio
import json
import traceback
from datetime import datetime
from typing import Any, Dict

import websockets
import yaml
from crewai import Agent, Task, Crew, Process

import tools as tools_module
import adapters as adapters_module


def _load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


AGENTS_CONFIG = _load_yaml("agents.yaml")
TASKS_CONFIG = _load_yaml("tasks.yaml")


TOOL_REGISTRY = getattr(tools_module, "TOOL_REGISTRY", {})
TASK_TOOLS = getattr(adapters_module, "TASK_TOOLS", {})
AGENT_TOOLS = getattr(adapters_module, "AGENT_TOOLS", {})


def _resolve_tools(names):
    """Converte lista de nomes em instâncias de tool via TOOL_REGISTRY."""
    out = []
    for name in names or []:
        inst = TOOL_REGISTRY.get(name)
        if inst is not None:
            out.append(inst)
    return out


def _build_agent(agent_id: str) -> Agent:
    cfg = AGENTS_CONFIG.get(agent_id, {})
    tool_names = AGENT_TOOLS.get(agent_id, [])
    return Agent(
        role=cfg.get("role", agent_id),
        goal=cfg.get("goal", ""),
        backstory=cfg.get("backstory", ""),
        verbose=cfg.get("verbose", True),
        allow_delegation=cfg.get("allow_delegation", False),
        tools=_resolve_tools(tool_names),
    )


def _build_task(task_id: str, agent: Agent, description: str) -> Task:
    cfg = TASKS_CONFIG.get(task_id, {})
    tool_names = TASK_TOOLS.get(task_id, [])
    return Task(
        description=description or cfg.get("description", ""),
        expected_output=cfg.get("expected_output", ""),
        agent=agent,
        tools=_resolve_tools(tool_names),
    )


async def _send(ws, msg_type: str, data: Any) -> None:
    await ws.send(json.dumps({
        "type": msg_type,
        "timestamp": datetime.utcnow().isoformat(),
        "data": data,
    }))


async def _execute_task(ws, task_name: str, input_data: Dict[str, Any]) -> None:
    await _send(ws, "task_start", {"task_name": task_name, "input_data": input_data})

    task_cfg = TASKS_CONFIG.get(task_name)
    if not task_cfg:
        await _send(ws, "error", {"task_name": task_name, "error": f"task '{task_name}' não definida em tasks.yaml"})
        return

    agent_id = task_cfg.get("agent") or task_cfg.get("agent_id")
    if not agent_id:
        await _send(ws, "error", {"task_name": task_name, "error": "task sem agente vinculado"})
        return

    try:
        agent = _build_agent(agent_id)

        # Aplica input_func (extrai dados de input_data → kwargs)
        input_fn = getattr(adapters_module, f"{task_name}_input_func", None)
        prepared = input_fn(input_data) if callable(input_fn) else input_data

        # Formata a descrição da task com inputs
        description = task_cfg.get("description", "")
        try:
            description = description.format(**prepared) if prepared else description
        except Exception:
            pass  # placeholders ausentes não impedem a execução

        task = _build_task(task_name, agent, description)
        crew = Crew(agents=[agent], tasks=[task], process=Process.sequential, verbose=False)

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, crew.kickoff)

        raw = getattr(result, "raw", None) or str(result)

        output_fn = getattr(adapters_module, f"{task_name}_output_func", None)
        if callable(output_fn):
            try:
                parsed = output_fn(input_data, raw)
            except Exception:
                parsed = {"raw": raw}
        else:
            parsed = {"raw": raw}

        await _send(ws, "task_completed", {"task_name": task_name, "result": parsed})
    except Exception as exc:
        await _send(ws, "error", {"task_name": task_name, "error": str(exc), "traceback": traceback.format_exc()})


async def _handle_client(ws):
    await _send(ws, "connected", {"available_tasks": list(TASKS_CONFIG.keys())})
    async for message in ws:
        try:
            payload = json.loads(message)
        except json.JSONDecodeError:
            await _send(ws, "error", {"error": "invalid JSON"})
            continue

        msg_type = payload.get("type")
        data = payload.get("data") or {}

        if msg_type == "execute_task":
            await _execute_task(ws, data.get("task_name"), data.get("input_data") or {})
        elif msg_type == "ping":
            await _send(ws, "pong", {"timestamp": datetime.utcnow().isoformat()})
        elif msg_type == "get_task_info":
            await _send(ws, "task_info", {"tasks": list(TASKS_CONFIG.keys())})
        else:
            await _send(ws, "error", {"error": f"unknown message type: {msg_type}"})


async def run_websocket_server(host: str = "localhost", port: int = 5002):
    async with websockets.serve(_handle_client, host, port, ping_interval=30, ping_timeout=10):
        print(f"🌐 WebSocket aceitando conexões em ws://{host}:{port}")
        await asyncio.Future()  # run forever
