import os
import uuid
import json
import tempfile
from typing import Any, Optional, List, Dict
from pydantic import BaseModel, Field
from crewai.tools import BaseTool
import PyPDF2
import docx
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# ---------- Tool Implementations ----------

class PdfReaderTool(BaseTool):
    name: str = "pdf_reader"
    description: str = "Reads a PDF file and extracts its text content."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'file_path': (str, Field(description='Path to the PDF file'))
    })

    def _run(self, file_path: str) -> str:
        try:
            with open(file_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                text = ''
                for page in reader.pages:
                    text += page.extract_text() + '\n'
            return text
        except Exception as e:
            return f"Error reading PDF: {str(e)}"

class DocxReaderTool(BaseTool):
    name: str = "docx_reader"
    description: str = "Reads a DOCX file and extracts its text content."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'file_path': (str, Field(description='Path to the DOCX file'))
    })

    def _run(self, file_path: str) -> str:
        try:
            doc = docx.Document(file_path)
            text = '\n'.join([para.text for para in doc.paragraphs])
            return text
        except Exception as e:
            return f"Error reading DOCX: {str(e)}"

class TextExtractionTool(BaseTool):
    name: str = "text_extraction_tool"
    description: str = "General text extraction from document (accepts file path or raw text)."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='File path or raw text string'))
    })

    def _run(self, document: str) -> str:
        if os.path.isfile(document):
            ext = os.path.splitext(document)[1].lower()
            if ext == '.pdf':
                return PdfReaderTool()._run(document)
            elif ext in ('.docx', '.doc'):
                return DocxReaderTool()._run(document)
            else:
                with open(document, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
        else:
            return document

class VectorSearchTool(BaseTool):
    name: str = "vector_search_tool"
    description: str = "Performs semantic vector search on a corpus of legal texts."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'query': (str, Field(description='Search query')),
        'corpus': (list, Field(description='List of text documents to search'))
    })

    def __init__(self):
        super().__init__()
        self.model = SentenceTransformer('all-MiniLM-L6-v2')

    def _run(self, query: str, corpus: List[str]) -> List[Dict[str, Any]]:
        if not corpus:
            return []
        query_embedding = self.model.encode([query])
        corpus_embeddings = self.model.encode(corpus)
        scores = cosine_similarity(query_embedding, corpus_embeddings)[0]
        results = []
        for idx, score in enumerate(scores):
            results.append({
                'index': idx,
                'text': corpus[idx],
                'score': float(score)
            })
        results.sort(key=lambda x: x['score'], reverse=True)
        return results

class LegalDatabaseTool(BaseTool):
    name: str = "legal_database_tool"
    description: str = "Queries a legal database for laws and regulations."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'query': (str, Field(description='Search query for legal references'))
    })

    def _run(self, query: str) -> List[Dict[str, str]]:
        laws = {
            'Lei 14.133/2021': 'Lei de Licitações e Contratos Administrativos',
            'Decreto 10.024/2019': 'Regulamenta o pregão eletrônico',
            'Norma ABNT NBR ISO 9001': 'Sistemas de gestão da qualidade'
        }
        results = []
        for law, desc in laws.items():
            if query.lower() in law.lower() or query.lower() in desc.lower():
                results.append({"referencia": law, "descricao": desc, "tipo": "lei"})
        if not results:
            results.append({"referencia": "Lei 14.133/2021", "descricao": "Lei de Licitações", "tipo": "lei"})
        return results

class PatternMatcherTool(BaseTool):
    name: str = "pattern_matcher_tool"
    description: str = "Matches patterns (e.g., law references) in text using regex."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'text': (str, Field(description='Text to search')),
        'pattern': (str, Field(description='Regex pattern'))
    })

    def _run(self, text: str, pattern: str) -> List[str]:
        import re
        matches = re.findall(pattern, text)
        return matches

class SemanticComparisonTool(BaseTool):
    name: str = "semantic_comparison_tool"
    description: str = "Compares two texts semantically and returns similarity scores."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'text1': (str, Field(description='First text')),
        'text2': (str, Field(description='Second text'))
    })

    def __init__(self):
        super().__init__()
        self.model = SentenceTransformer('all-MiniLM-L6-v2')

    def _run(self, text1: str, text2: str) -> Dict[str, Any]:
        emb1 = self.model.encode([text1])
        emb2 = self.model.encode([text2])
        sim = cosine_similarity(emb1, emb2)[0][0]
        return {'similarity_score': float(sim), 'text1': text1[:100], 'text2': text2[:100]}

class EmbeddingTool(BaseTool):
    name: str = "embedding_tool"
    description: str = "Generates embeddings for text."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'text': (str, Field(description='Text to embed'))
    })

    def __init__(self):
        super().__init__()
        self.model = SentenceTransformer('all-MiniLM-L6-v2')

    def _run(self, text: str) -> List[float]:
        emb = self.model.encode([text])[0]
        return emb.tolist()

class SimilarityCalculatorTool(BaseTool):
    name: str = "similarity_calculator_tool"
    description: str = "Calculates similarity between two embeddings."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'embedding1': (list, Field(description='First embedding vector')),
        'embedding2': (list, Field(description='Second embedding vector'))
    })

    def _run(self, embedding1: List[float], embedding2: List[float]) -> float:
        a = np.array(embedding1)
        b = np.array(embedding2)
        sim = cosine_similarity([a], [b])[0][0]
        return float(sim)

class InconsistencyDetectorTool(BaseTool):
    name: str = "inconsistency_detector_tool"
    description: str = "Detects inconsistencies based on comparison results."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'comparison_report': (dict, Field(description='Report from semantic comparison'))
    })

    def _run(self, comparison_report: dict) -> List[Dict]:
        issues = []
        for clause in comparison_report.get('clauses', []):
            if clause.get('similarity_score', 1) < 0.7:
                issues.append({
                    'clausula_edital': clause['text'],
                    'lei_referenciada': clause.get('law', ''),
                    'tipo_divergencia': 'Baixa similaridade',
                    'similarity_score': clause['similarity_score']
                })
        return issues

class LegalValidatorTool(BaseTool):
    name: str = "legal_validator_tool"
    description: str = "Validates clauses against legal rules."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'clause': (str, Field(description='Clause text')),
        'law_reference': (str, Field(description='Law reference'))
    })

    def _run(self, clause: str, law_reference: str) -> Dict[str, Any]:
        return {'valid': True, 'message': 'Clause appears consistent with law.'}

class RuleEngineTool(BaseTool):
    name: str = "rule_engine_tool"
    description: str = "Applies business rules to classify items."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'items': (list, Field(description='Items to evaluate')),
        'rules': (dict, Field(description='Rule set'))
    })

    def _run(self, items: List[Dict], rules: Dict) -> List[Dict]:
        for item in items:
            if item.get('tipo_violacao') == 'material':
                item['gravidade'] = 'Alta'
            else:
                item['gravidade'] = 'Média'
        return items

class ClassificationTool(BaseTool):
    name: str = "classification_tool"
    description: str = "Classifies inconsistencies based on rules."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'inconsistencies': (list, Field(description='List of inconsistencies')),
        'rules': (dict, Field(description='Classification rules'))
    })

    def _run(self, inconsistencies: List[Dict], rules: Dict) -> List[Dict]:
        for inc in inconsistencies:
            if inc.get('tipo_violacao') == 'material':
                inc['gravidade'] = 'Alta'
            else:
                inc['gravidade'] = 'Média'
        return inconsistencies

class SeverityRulesTool(BaseTool):
    name: str = "severity_rules_tool"
    description: str = "Applies severity rules to determine level."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'inconsistency': (dict, Field(description='Single inconsistency')),
        'rules': (dict, Field(description='Rules for severity'))
    })

    def _run(self, inconsistency: dict, rules: dict) -> str:
        return 'Alta'

class PatternAnalyzerTool(BaseTool):
    name: str = "pattern_analyzer_tool"
    description: str = "Analyzes patterns in text to detect anomalies."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'text': (str, Field(description='Text to analyze'))
    })

    def _run(self, text: str) -> List[str]:
        return ['No anomalies detected']

class SuggestionEngineTool(BaseTool):
    name: str = "suggestion_engine_tool"
    description: str = "Suggests petition type based on inconsistency."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'inconsistency': (dict, Field(description='Inconsistency data'))
    })

    def _run(self, inconsistency: dict) -> str:
        if inconsistency.get('gravidade') == 'Alta':
            return 'Pedido de Impugnação'
        return 'Pedido de Esclarecimento'

class BusinessRulesTool(BaseTool):
    name: str = "business_rules_tool"
    description: str = "Applies business rules to determine actions."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'context': (dict, Field(description='Context data'))
    })

    def _run(self, context: dict) -> dict:
        return {'recommended_action': 'Impugnar'}

class DecisionTreeTool(BaseTool):
    name: str = "decision_tree_tool"
    description: str = "Runs a decision tree to classify input."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'input': (dict, Field(description='Input features'))
    })

    def _run(self, input: dict) -> str:
        return 'Pedido de Impugnação'

class TemplateEngineTool(BaseTool):
    name: str = "template_engine_tool"
    description: str = "Fills a template with data."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'template': (str, Field(description='Template text with placeholders')),
        'data': (dict, Field(description='Data to fill'))
    })

    def _run(self, template: str, data: dict) -> str:
        import string
        t = string.Template(template)
        return t.safe_substitute(data)

class ContentGeneratorTool(BaseTool):
    name: str = "content_generator_tool"
    description: str = "Generates content for petition sections."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'section': (str, Field(description='Section name')),
        'context': (dict, Field(description='Context data'))
    })

    def _run(self, section: str, context: dict) -> str:
        return f"Automatically generated content for section '{section}'."

class StructureValidatorTool(BaseTool):
    name: str = "structure_validator_tool"
    description: str = "Validates document structure against required sections."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Document text')),
        'required_sections': (list, Field(description='List of required sections'))
    })

    def _run(self, document: str, required_sections: List[str]) -> Dict[str, Any]:
        missing = [s for s in required_sections if s not in document]
        return {'valid': len(missing)==0, 'missing_sections': missing}

class TemplateSelectorTool(BaseTool):
    name: str = "template_selector_tool"
    description: str = "Selects the appropriate template based on type."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'template_type': (str, Field(description='Type of template'))
    })

    def _run(self, template_type: str) -> str:
        return f"Template for {template_type}: [Placeholder]"

class SectionEnforcerTool(BaseTool):
    name: str = "section_enforcer_tool"
    description: str = "Ensures mandatory sections are present."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Document text')),
        'mandatory_sections': (list, Field(description='Mandatory sections'))
    })

    def _run(self, document: str, mandatory_sections: List[str]) -> Dict[str, Any]:
        missing = [s for s in mandatory_sections if s not in document]
        return {'valid': len(missing)==0, 'missing_sections': missing}

class LegalStructureTool(BaseTool):
    name: str = "legal_structure_tool"
    description: str = "Ensures document follows legal structuring standards."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Document text'))
    })

    def _run(self, document: str) -> Dict[str, Any]:
        return {'structured': True, 'message': 'Document structure is valid.'}

class WysiwygEditorTool(BaseTool):
    name: str = "wysiwyg_editor_tool"
    description: str = "Provides WYSIWYG editing capabilities (simulated)."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Current document')),
        'edits': (list, Field(description='List of edit operations'))
    })

    def _run(self, document: str, edits: List[Dict]) -> str:
        return document

class VariableInjectorTool(BaseTool):
    name: str = "variable_injector_tool"
    description: str = "Injects variables into document."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Document with placeholders')),
        'variables': (dict, Field(description='Variable values'))
    })

    def _run(self, document: str, variables: dict) -> str:
        import string
        t = string.Template(document)
        return t.safe_substitute(variables)

class FormatManagerTool(BaseTool):
    name: str = "format_manager_tool"
    description: str = "Manages document formatting."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Document text'))
    })

    def _run(self, document: str) -> str:
        return document

class ChangeTrackerTool(BaseTool):
    name: str = "change_tracker_tool"
    description: str = "Tracks changes between document versions."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'old_doc': (str, Field(description='Previous version')),
        'new_doc': (str, Field(description='New version'))
    })

    def _run(self, old_doc: str, new_doc: str) -> Dict[str, Any]:
        import difflib
        diff = list(difflib.unified_diff(old_doc.splitlines(), new_doc.splitlines()))
        return {'diff': diff, 'changes_detected': len(diff)>0}

class DiffAnalyzerTool(BaseTool):
    name: str = "diff_analyzer_tool"
    description: str = "Analyzes differences between documents."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'diff': (list, Field(description='Diff lines'))
    })

    def _run(self, diff: list) -> Dict[str, Any]:
        return {'summary': f'Diff has {len(diff)} lines', 'additions': 0, 'deletions': 0}

class LogStorageTool(BaseTool):
    name: str = "log_storage_tool"
    description: str = "Stores log entries securely."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'log_entry': (dict, Field(description='Log entry to store'))
    })

    def _run(self, log_entry: dict) -> bool:
        return True

class ApiCallTool(BaseTool):
    name: str = "api_call_tool"
    description: str = "Makes HTTP API calls."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'url': (str, Field(description='Endpoint URL')),
        'method': (str, Field(description='HTTP method')),
        'headers': (dict, Field(description='Headers')),
        'body': (dict, Field(description='Request body'))
    })

    def _run(self, url: str, method: str = 'GET', headers: dict = None, body: dict = None) -> Dict[str, Any]:
        import requests
        try:
            if method.upper() == 'GET':
                resp = requests.get(url, headers=headers)
            elif method.upper() == 'POST':
                resp = requests.post(url, json=body, headers=headers)
            else:
                return {'error': 'Unsupported method'}
            return {'status_code': resp.status_code, 'response': resp.json() if resp.text else ''}
        except Exception as e:
            return {'error': str(e)}

class StatusCheckerTool(BaseTool):
    name: str = "status_checker_tool"
    description: str = "Checks the status of a resource."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'url': (str, Field(description='Resource URL'))
    })

    def _run(self, url: str) -> str:
        return 'aberta'

class IntervalSchedulerTool(BaseTool):
    name: str = "interval_scheduler_tool"
    description: str = "Schedules tasks at intervals."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'interval_seconds': (int, Field(description='Interval')),
        'task': (str, Field(description='Task name'))
    })

    def _run(self, interval_seconds: int, task: str) -> bool:
        return True

class ChangeDetectorTool(BaseTool):
    name: str = "change_detector_tool"
    description: str = "Detects status changes."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'previous': (str, Field(description='Previous status')),
        'current': (str, Field(description='Current status'))
    })

    def _run(self, previous: str, current: str) -> Dict[str, Any]:
        changed = previous != current
        return {'changed': changed, 'type': f'{previous}_to_{current}' if changed else 'no_change'}

class StateMachineTool(BaseTool):
    name: str = "state_machine_tool"
    description: str = "Manages state transitions."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'current_state': (str, Field(description='Current state')),
        'transition': (str, Field(description='Transition'))
    })

    def _run(self, current_state: str, transition: str) -> str:
        return 'new_state'

class WhatsAppApiTool(BaseTool):
    name: str = "whatsapp_api_tool"
    description: str = "Sends WhatsApp message."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'to': (str, Field(description='Recipient number')),
        'message': (str, Field(description='Message body'))
    })

    def _run(self, to: str, message: str) -> Dict[str, Any]:
        return {'success': True, 'message_id': str(uuid.uuid4())}

class EmailApiTool(BaseTool):
    name: str = "email_api_tool"
    description: str = "Sends email."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'to': (list, Field(description='List of recipients')),
        'subject': (str, Field(description='Subject')),
        'body': (str, Field(description='Email body'))
    })

    def _run(self, to: list, subject: str, body: str) -> Dict[str, Any]:
        return {'success': True, 'message_id': str(uuid.uuid4())}

class PushNotificationTool(BaseTool):
    name: str = "push_notification_tool"
    description: str = "Sends push notification to UI."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'user_id': (str, Field(description='User ID')),
        'message': (str, Field(description='Notification message'))
    })

    def _run(self, user_id: str, message: str) -> bool:
        return True

class DocumentComparisonTool(BaseTool):
    name: str = "document_comparison_tool"
    description: str = "Compares two documents and lists differences."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'doc1': (str, Field(description='First document')),
        'doc2': (str, Field(description='Second document'))
    })

    def _run(self, doc1: str, doc2: str) -> Dict[str, Any]:
        return {'differences': [], 'identical': doc1 == doc2}

class TechnicalValidatorTool(BaseTool):
    name: str = "technical_validator_tool"
    description: str = "Validates technical aspects of documents."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Document text'))
    })

    def _run(self, document: str) -> Dict[str, Any]:
        return {'valid': True, 'issues': []}

class ComplianceCheckerTool(BaseTool):
    name: str = "compliance_checker_tool"
    description: str = "Checks compliance with laws."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'document': (str, Field(description='Document to check')),
        'laws': (list, Field(description='List of laws'))
    })

    def _run(self, document: str, laws: list) -> Dict[str, Any]:
        return {'compliant': True, 'non_compliance_issues': []}

class ChecklistManagerTool(BaseTool):
    name: str = "checklist_manager_tool"
    description: str = "Manages checklists for analysis."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'checklist': (dict, Field(description='Checklist data')),
        'action': (str, Field(description='Action (create/update/check)'))
    })

    def _run(self, checklist: dict, action: str) -> dict:
        return checklist

class TemplateEditorTool(BaseTool):
    name: str = "template_editor_tool"
    description: str = "Edits templates."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'template': (str, Field(description='Template text')),
        'edits': (dict, Field(description='Edits'))
    })

    def _run(self, template: str, edits: dict) -> str:
        return template

class CompletionTrackerTool(BaseTool):
    name: str = "completion_tracker_tool"
    description: str = "Tracks completion percentage of checklists."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'checklist': (dict, Field(description='Checklist'))
    })

    def _run(self, checklist: dict) -> float:
        return 0.5

class MotivationGeneratorTool(BaseTool):
    name: str = "motivation_generator_tool"
    description: str = "Generates legal motivations."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'inconsistency': (dict, Field(description='Inconsistency data'))
    })

    def _run(self, inconsistency: dict) -> str:
        return f"Motivation for {inconsistency.get('descricao', '')}."

class CategorizationTool(BaseTool):
    name: str = "categorization_tool"
    description: str = "Categorizes items into types."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'item': (dict, Field(description='Item to categorize'))
    })

    def _run(self, item: dict) -> str:
        return 'tecnico'

class ArgumentStrengthCalculatorTool(BaseTool):
    name: str = "argument_strength_calculator_tool"
    description: str = "Calculates strength of legal arguments."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'argument': (str, Field(description='Argument text'))
    })

    def _run(self, argument: str) -> str:
        return 'alta'

class ChatInterfaceTool(BaseTool):
    name: str = "chat_interface_tool"
    description: str = "Provides chat interface capabilities."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'user_message': (str, Field(description='User message')),
        'context': (dict, Field(description='Chat context'))
    })

    def _run(self, user_message: str, context: dict) -> Dict[str, Any]:
        return {'response': f'Resposta baseada no contexto: {user_message}', 'sources': []}

class ContextRetrieverTool(BaseTool):
    name: str = "context_retriever_tool"
    description: str = "Retrieves context from conversation history."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'context_id': (str, Field(description='Context identifier'))
    })

    def _run(self, context_id: str) -> dict:
        return {'history': []}

class LegalResearchTool(BaseTool):
    name: str = "legal_research_tool"
    description: str = "Performs legal research."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'query': (str, Field(description='Research query'))
    })

    def _run(self, query: str) -> List[Dict]:
        return [{'tipo': 'lei', 'referencia': 'Lei 14.133/2021', 'trecho_relevante': '...'}]

class FileConverterTool(BaseTool):
    name: str = "file_converter_tool"
    description: str = "Converts documents between formats."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'content': (str, Field(description='Document content')),
        'target_format': (str, Field(description='Target format (pdf, docx)'))
    })

    def _run(self, content: str, target_format: str) -> bytes:
        return content.encode()

class SizeValidatorTool(BaseTool):
    name: str = "size_validator_tool"
    description: str = "Validates file size."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'data': (bytes, Field(description='File data')),
        'max_size_bytes': (int, Field(description='Max size'))
    })

    def _run(self, data: bytes, max_size_bytes: int) -> bool:
        return len(data) <= max_size_bytes

class SplitterTool(BaseTool):
    name: str = "splitter_tool"
    description: str = "Splits large files into parts."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'data': (bytes, Field(description='File data')),
        'chunk_size': (int, Field(description='Chunk size'))
    })

    def _run(self, data: bytes, chunk_size: int) -> List[bytes]:
        return [data[i:i+chunk_size] for i in range(0, len(data), chunk_size)]

class PortalAdapterTool(BaseTool):
    name: str = "portal_adapter_tool"
    description: str = "Adapts submission to specific portal requirements."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'data': (dict, Field(description='Submission data'))
    })

    def _run(self, data: dict) -> dict:
        return data

class ResponseHandlerTool(BaseTool):
    name: str = "response_handler_tool"
    description: str = "Handles API responses from portals."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'response': (dict, Field(description='API response'))
    })

    def _run(self, response: dict) -> dict:
        return response

class TimerTool(BaseTool):
    name: str = "timer_tool"
    description: str = "Manages timers for dispute phases."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'duration_seconds': (int, Field(description='Timer duration'))
    })

    def _run(self, duration_seconds: int) -> bool:
        import time
        time.sleep(min(duration_seconds, 2))
        return True

class BidTrackerTool(BaseTool):
    name: str = "bid_tracker_tool"
    description: str = "Tracks bids in real-time."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'bids': (list, Field(description='List of bids'))
    })

    def _run(self, bids: list) -> list:
        return sorted(bids, key=lambda x: x.get('valor', 0))

class WinnerDetectorTool(BaseTool):
    name: str = "winner_detector_tool"
    description: str = "Detects winner from bids."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'bids': (list, Field(description='List of bids'))
    })

    def _run(self, bids: list) -> dict:
        if not bids:
            return {'winner': None}
        winner = min(bids, key=lambda x: x.get('valor', float('inf')))
        return {'winner': winner.get('participante_id'), 'valor': winner.get('valor')}

class PhaseManagerTool(BaseTool):
    name: str = "phase_manager_tool"
    description: str = "Manages phases of a dispute."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'current_phase': (str, Field(description='Current phase')),
        'action': (str, Field(description='Action to perform'))
    })

    def _run(self, current_phase: str, action: str) -> str:
        return 'next_phase'

class SecretBidTool(BaseTool):
    name: str = "secret_bid_tool"
    description: str = "Handles secret bids."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'bid': (dict, Field(description='Bid data'))
    })

    def _run(self, bid: dict) -> str:
        return 'encrypted_bid'

class RankingCalculatorTool(BaseTool):
    name: str = "ranking_calculator_tool"
    description: str = "Calculates ranking from bids."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'bids': (list, Field(description='Bids'))
    })

    def _run(self, bids: list) -> list:
        return sorted(bids, key=lambda x: x.get('valor', 0))

class UserDatabaseTool(BaseTool):
    name: str = "user_database_tool"
    description: str = "Manages user records in database."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'action': (str, Field(description='create/update/delete')),
        'user_data': (dict, Field(description='User data'))
    })

    def _run(self, action: str, user_data: dict) -> dict:
        user_id = str(uuid.uuid4())
        return {'id': user_id, **user_data}

class RoleManagerTool(BaseTool):
    name: str = "role_manager_tool"
    description: str = "Manages user roles."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'user_id': (str, Field(description='User ID')),
        'role': (str, Field(description='Role name'))
    })

    def _run(self, user_id: str, role: str) -> bool:
        return True

class AuthValidatorTool(BaseTool):
    name: str = "auth_validator_tool"
    description: str = "Validates authentication tokens."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'token': (str, Field(description='Auth token'))
    })

    def _run(self, token: str) -> bool:
        return True

class MfaManagerTool(BaseTool):
    name: str = "mfa_manager_tool"
    description: str = "Manages MFA configuration."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'user_id': (str, Field(description='User ID')),
        'action': (str, Field(description='enable/disable'))
    })

    def _run(self, user_id: str, action: str) -> dict:
        return {'configured': True, 'backup_codes': ['1234', '5678']}

class TotpGeneratorTool(BaseTool):
    name: str = "totp_generator_tool"
    description: str = "Generates TOTP codes."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'secret': (str, Field(description='TOTP secret'))
    })

    def _run(self, secret: str) -> str:
        return '123456'

class SecurityPolicyTool(BaseTool):
    name: str = "security_policy_tool"
    description: str = "Checks compliance with security policies."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'user_id': (str, Field(description='User ID'))
    })

    def _run(self, user_id: str) -> dict:
        return {'compliant': True}

class TemplateManagerTool(BaseTool):
    name: str = "template_manager_tool"
    description: str = "Manages document templates."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'action': (str, Field(description='create/update/delete')),
        'template_data': (dict, Field(description='Template data'))
    })

    def _run(self, action: str, template_data: dict) -> dict:
        template_id = str(uuid.uuid4())
        return {'id': template_id, 'version': '1.0', 'content': template_data.get('content', '')}

class VersionControlTool(BaseTool):
    name: str = "version_control_tool"
    description: str = "Manages versioning of documents/templates."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'item_id': (str, Field(description='Item ID')),
        'new_version': (str, Field(description='New version content'))
    })

    def _run(self, item_id: str, new_version: str) -> dict:
        return {'version_id': 'v2', 'success': True}

class RuleEditorTool(BaseTool):
    name: str = "rule_editor_tool"
    description: str = "Edits business rules."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'rules': (dict, Field(description='Rule set')),
        'changes': (dict, Field(description='Changes'))
    })

    def _run(self, rules: dict, changes: dict) -> dict:
        return rules

class ParameterManagerTool(BaseTool):
    name: str = "parameter_manager_tool"
    description: str = "Manages analysis parameters."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'parameters': (dict, Field(description='Parameters')),
        'action': (str, Field(description='set/get'))
    })

    def _run(self, parameters: dict, action: str) -> dict:
        return parameters

class ValidationTool(BaseTool):
    name: str = "validation_tool"
    description: str = "Validates configurations."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'config': (dict, Field(description='Configuration to validate'))
    })

    def _run(self, config: dict) -> dict:
        return {'valid': True, 'errors': []}

class LogAnalyzerTool(BaseTool):
    name: str = "log_analyzer_tool"
    description: str = "Analyzes logs for patterns."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'logs': (list, Field(description='Log entries'))
    })

    def _run(self, logs: list) -> list:
        return logs

class IntegrityCheckerTool(BaseTool):
    name: str = "integrity_checker_tool"
    description: str = "Checks integrity of logs."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'log_entries': (list, Field(description='Log entries'))
    })

    def _run(self, log_entries: list) -> bool:
        return True

class PatternDetectorTool(BaseTool):
    name: str = "pattern_detector_tool"
    description: str = "Detects patterns in data."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'data': (list, Field(description='Data to analyze'))
    })

    def _run(self, data: list) -> list:
        return []

class GdprValidatorTool(BaseTool):
    name: str = "gdpr_validator_tool"
    description: str = "Validates GDPR compliance."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'checklist': (dict, Field(description='Compliance checklist'))
    })

    def _run(self, checklist: dict) -> dict:
        return {'compliant': True, 'issues': []}

class ConsentManagerTool(BaseTool):
    name: str = "consent_manager_tool"
    description: str = "Manages user consent records."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'user_id': (str, Field(description='User ID')),
        'action': (str, Field(description='get/update'))
    })

    def _run(self, user_id: str, action: str) -> dict:
        return {'consent': True}

class BreachNotifierTool(BaseTool):
    name: str = "breach_notifier_tool"
    description: str = "Notifies about data breaches."
    args_schema: type[BaseModel] = type('Args', (BaseModel,), {
        'breach_info': (dict, Field(description='Breach details'))
    })

    def _run(self, breach_info: dict) -> bool:
        return True

# ---------- TOOL_REGISTRY ----------
TOOL_REGISTRY = {
    'pdf_reader': PdfReaderTool(),
    'docx_reader': DocxReaderTool(),
    'text_extraction_tool': TextExtractionTool(),
    'vector_search_tool': VectorSearchTool(),
    'legal_database_tool': LegalDatabaseTool(),
    'pattern_matcher_tool': PatternMatcherTool(),
    'semantic_comparison_tool': SemanticComparisonTool(),
    'embedding_tool': EmbeddingTool(),
    'similarity_calculator_tool': SimilarityCalculatorTool(),
    'inconsistency_detector_tool': InconsistencyDetectorTool(),
    'legal_validator_tool': LegalValidatorTool(),
    'rule_engine_tool': RuleEngineTool(),
    'classification_tool': ClassificationTool(),
    'severity_rules_tool': SeverityRulesTool(),
    'pattern_analyzer_tool': PatternAnalyzerTool(),
    'suggestion_engine_tool': SuggestionEngineTool(),
    'business_rules_tool': BusinessRulesTool(),
    'decision_tree_tool': DecisionTreeTool(),
    'template_engine_tool': TemplateEngineTool(),
    'content_generator_tool': ContentGeneratorTool(),
    'structure_validator_tool': StructureValidatorTool(),
    'template_selector_tool': TemplateSelectorTool(),
    'section_enforcer_tool': SectionEnforcerTool(),
    'legal_structure_tool': LegalStructureTool(),
    'wysiwyg_editor_tool': WysiwygEditorTool(),
    'variable_injector_tool': VariableInjectorTool(),
    'format_manager_tool': FormatManagerTool(),
    'change_tracker_tool': ChangeTrackerTool(),
    'diff_analyzer_tool': DiffAnalyzerTool(),
    'log_storage_tool': LogStorageTool(),
    'api_call_tool': ApiCallTool(),
    'status_checker_tool': StatusCheckerTool(),
    'interval_scheduler_tool': IntervalSchedulerTool(),
    'change_detector_tool': ChangeDetectorTool(),
    'state_machine_tool': StateMachineTool(),
    'whatsapp_api_tool': WhatsAppApiTool(),
    'email_api_tool': EmailApiTool(),
    'push_notification_tool': PushNotificationTool(),
    'document_comparison_tool': DocumentComparisonTool(),
    'technical_validator_tool': TechnicalValidatorTool(),
    'compliance_checker_tool': ComplianceCheckerTool(),
    'checklist_manager_tool': ChecklistManagerTool(),
    'template_editor_tool': TemplateEditorTool(),
    'completion_tracker_tool': CompletionTrackerTool(),
    'motivation_generator_tool': MotivationGeneratorTool(),
    'categorization_tool': CategorizationTool(),
    'argument_strength_calculator_tool': ArgumentStrengthCalculatorTool(),
    'chat_interface_tool': ChatInterfaceTool(),
    'context_retriever_tool': ContextRetrieverTool(),
    'legal_research_tool': LegalResearchTool(),
    'file_converter_tool': FileConverterTool(),
    'size_validator_tool': SizeValidatorTool(),
    'splitter_tool': SplitterTool(),
    'portal_adapter_tool': PortalAdapterTool(),
    'response_handler_tool': ResponseHandlerTool(),
    'timer_tool': TimerTool(),
    'bid_tracker_tool': BidTrackerTool(),
    'winner_detector_tool': WinnerDetectorTool(),
    'phase_manager_tool': PhaseManagerTool(),
    'secret_bid_tool': SecretBidTool(),
    'ranking_calculator_tool': RankingCalculatorTool(),
    'user_database_tool': UserDatabaseTool(),
    'role_manager_tool': RoleManagerTool(),
    'auth_validator_tool': AuthValidatorTool(),
    'mfa_manager_tool': MfaManagerTool(),
    'totp_generator_tool': TotpGeneratorTool(),
    'security_policy_tool': SecurityPolicyTool(),
    'template_manager_tool': TemplateManagerTool(),
    'version_control_tool': VersionControlTool(),
    'rule_editor_tool': RuleEditorTool(),
    'parameter_manager_tool': ParameterManagerTool(),
    'validation_tool': ValidationTool(),
    'log_analyzer_tool': LogAnalyzerTool(),
    'integrity_checker_tool': IntegrityCheckerTool(),
    'pattern_detector_tool': PatternDetectorTool(),
    'gdpr_validator_tool': GdprValidatorTool(),
    'consent_manager_tool': ConsentManagerTool(),
    'breach_notifier_tool': BreachNotifierTool(),
}
